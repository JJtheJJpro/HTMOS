#![no_std]
#![no_main]

use core::panic::PanicInfo;

#[unsafe(no_mangle)]
pub extern "C" fn kmain() -> ! {
    const VGA_BUFFER: *mut u16 = 0xb8000 as *mut u16;

    unsafe {
        const TO_WRITE: &[u8] = b"HTMOS BIOS BOOTLOADER";
        for i in 0..TO_WRITE.len() {
            VGA_BUFFER.add(i).write_volatile(TO_WRITE[i] as u16);
        }
        VGA_BUFFER.write_volatile(b'R' as u16); // Character
        VGA_BUFFER.add(1).write_volatile(0x0B); // Color (Cyan)
    }

    loop {}
}

#[panic_handler]
fn panic(_info: &PanicInfo) -> ! {
    loop {}
}
